Purpose of Game:

A coding exercise and exploration of different Unity Tools and Elements. 

Purpose of Abandonment: 

It was determined it was neither an engaging game nor induces
the crippling feeling of going through a blizzard to the player. 

Might revisit the concept but will be abandoning the code as I've now 
learned of an even easier and more professional way to organize such projects. 
